
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/*// TODO Auto-generated method stub
		Student stu=new Student("201806060101","�ŷ�","Ů",21);
		//Student stu1=new Student("201806060101","�ŷ�","Ů",21);
		//System.out.println(stu==stu1);
		stu.study();
		stu.goToClass();
		stu.exam();*/
		
		Driver driver=new Driver("����","��",35,"d001");
		Passanger pass1=new Passanger("����",25,"��");
		Passanger pass2=new Passanger("����",26,"��");
		Passanger pass3=new Passanger("�ŷ�",25,"Ů");
		Passanger pass4=new Passanger("��һ",31,"��");
		
		Bus bus=new Bus("���ǵ�",50);
		bus.setDriver(driver);
		bus.setLineNum("336");
		bus.setStartTime("06:00");
		bus.setEndTime("23:30");
		
		bus.upOnePass(pass1);
		bus.upOnePass(pass2);
		bus.upOnePass(pass3);
		System.out.println("��ǰ�˿�����"+bus.getCurrentCount());
		bus.downOnePass(pass2);
		bus.downOnePass(pass3);
		System.out.println("��ǰ�˿�����"+bus.getCurrentCount());

	
	}

}
