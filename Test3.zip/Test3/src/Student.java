
public class Student {
	//����
	private String num;
	private String name;
	private String sex;
	private int age;
	
	//����
	public void study()
	{
		System.out.println(name+"��ѧϰ");
	}
	
	public void goToClass()
	{
		System.out.println(name+"���Ͽ�");
	}
	
	public void exam()
	{
		System.out.println(name+"�ڿ���");
	}
	
	//���췽��
	public Student(String num,String name,String sex,int age)
	{
		setNum(num);
		setName(name);
		setSex(sex);
		setAge(age);
	}

	public void setNum(String num) {
		if(num.length()==12)
		{
			this.num=num;
		}
	}

	public String getNum() {
		return num;
	}
	
	public void setName(String name) {
		this.name=name;
	}

	public String getName() {
		return name;
	}

	public void setSex(String sex) {
		if((sex.equals("��"))||(sex.equals("Ů")))
		{
			this.sex = sex;
		}
	}

	public String getSex() {
		return sex;
	}

	public void setAge(int age) {
		if(age>=16)
		{
			this.age=age;
		}
	}

	public int getAge() {
		return age;
	}
}
