
public class Bus {
	private String carNum;
	private String brand;
	private String num;
	private String lineNum;
	private int maxCount;
	private int currentCount;//��ǰ�˿�����
	private String startTime;
	private String endTime;
	private Driver driver;
	private Passanger[] passList;
	
	public Bus(String brand,int maxCount)
	{
		this.setBrand(brand);
		this.setMaxCount(maxCount);
		passList=new Passanger[maxCount];
	}

	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}

	public String getCarNum() {
		return carNum;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getBrand() {
		return brand;
	}

	public void setNum(String num) {
		this.num = num;
	}

	public String getNum() {
		return num;
	}

	public void setLineNum(String lineNum) {
		this.lineNum = lineNum;
	}

	public String getLineNum() {
		return lineNum;
	}

	public void setMaxCount(int maxCount) {
		this.maxCount = maxCount;
	}

	public int getMaxCount() {
		return maxCount;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setDriver(Driver driver) {
		this.driver = driver;
	}

	public Driver getDriver() {
		return driver;
	}

	public void setPassList(Passanger[] passList) {
		this.passList = passList;
	}

	public Passanger[] getPassList() {
		return passList;
	}
	
	//�˿��ϳ��ķ���
	public void upPasses(Passanger[] upPassList)
	{
		for(int i=0;i<upPassList.length;i++)
		{
			upOnePass(upPassList[i]);
		}
	}
	
	public void upOnePass(Passanger pass)
	{
		if(currentCount==maxCount)
		{
			System.out.println("�����һ��");
		}
		else
		{
			currentCount++;
			for(int i=0;i<passList.length;i++)
			{
				if(passList[i]==null)
				{
					passList[i]=pass;
					System.out.println(pass.getName()+"���ϳ�");
					break;
				}
			}
		}
	}
	
	public void downOnePass(Passanger pass)
	{
		for(int i=0;i<passList.length;i++)
		{
			if(passList[i]!=null)
			{
			if(passList[i].equals(pass))
			{
				passList[i]=null;
				System.out.println(pass.getName()+"���³�");
				currentCount--;
				break;
			}
			}
		}
	}
	
	public void downPasses(Passanger[] downPassList)
	{
		for(int i=0;i<downPassList.length;i++)
		{
			downOnePass(downPassList[i]);
		}
	}

	public void setCurrentCount(int currentCount) {
		this.currentCount = currentCount;
	}

	public int getCurrentCount() {
		return currentCount;
	}
}
