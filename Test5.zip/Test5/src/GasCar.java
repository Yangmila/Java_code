
public class GasCar extends Car {


	public GasCar(String brand,String color) {
		super(brand,color);
	}
	
	public void addEn()
	{
		System.out.println("���ͳ�����");
	}

}
