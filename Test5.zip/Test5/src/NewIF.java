
public interface NewIF 
{
	public int add(int x,int y);
}
