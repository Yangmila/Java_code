
public class EleCar extends Car {

	public EleCar(String brand,String color) {
		super(brand,color);
	}
	
	public void addEn()
	{
		System.out.println("�綯�����");
	}

}
