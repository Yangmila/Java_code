
public class MyGasCar extends MyCar implements GasIF {

	@Override
	public void addGas() {
		System.out.println("����");
	}
	
	public MyGasCar(String brand,String color)
	{
		super(brand,color);
	}

}
