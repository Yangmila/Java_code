//������
public class A {

	public static void main(String[] args)
	{
		//NewIF test=new MyTest();
		NewIF test=new B();
		System.out.println(test.add(3, 5));
	}
}
