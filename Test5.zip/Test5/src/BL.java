
public class BL {

	public String[] findCnamesBySno(String sno)
	{
		BL_SCDAO_IF dao1=new BLTest();
		String[] cnos=dao1.findCnosBySno("s01");
		BL_CourseDAO_IF dao2=new BLTest();
		return dao2.findCnamesByCnos(cnos);
	}
}
