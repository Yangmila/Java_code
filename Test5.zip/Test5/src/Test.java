
public class Test {
	public static void main(String[] args)
	{
		Animal animal=new Dog("��",6);
		animal.eat();
		animal.sleep();
	}
}
