
public interface GasIF {

	public void addGas();
}
