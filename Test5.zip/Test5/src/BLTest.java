
public class BLTest implements BL_SCDAO_IF, BL_CourseDAO_IF {

	@Override
	public String[] findCnosBySno(String sno) {
		String[] cnos={"c01","c02"};
		return cnos;
	}

	@Override
	public String[] findCnamesByCnos(String[] cnos) {
		String[] cnames={"cname1","cname2"};
		return cnames;
	}

}
