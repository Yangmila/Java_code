
public class MyGasEleCar extends MyCar implements TestIF {

	@Override
	public void addEle() {
		System.out.println("���");

	}

	@Override
	public void addGas() {
		System.out.println("����");
	}
	
	public MyGasEleCar(String brand,String color)
	{
		super(brand,color);
	}
}
