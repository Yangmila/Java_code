
public class SCDAO implements BL_SCDAO_IF{

	public String[] findCnosBySno(String sno)
	{
		
	}
}
