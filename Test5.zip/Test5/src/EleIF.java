
public interface EleIF {

	public void addEle();
}
