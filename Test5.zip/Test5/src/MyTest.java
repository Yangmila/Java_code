
public class MyTest implements NewIF{

	public int add(int x,int y)
	{
		return 100;
	}
}
