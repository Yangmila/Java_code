
public interface TestIF extends EleIF, GasIF {

}
