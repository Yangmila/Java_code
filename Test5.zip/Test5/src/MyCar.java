
public class MyCar {
	private String brand;
	private String color;
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getBrand() {
		return brand;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getColor() {
		return color;
	}
	
	public MyCar(String brand,String color)
	{	
		setBrand(brand);
		setColor(color);
	}
	
	public void run()
	{
		System.out.println("������ʻ");
	}
	
}
