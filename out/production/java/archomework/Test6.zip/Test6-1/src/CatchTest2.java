
public class CatchTest2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("����ʼ");
		try
		{
			System.out.println(5/0);
		}
		catch(ArithmeticException ex)
		{
			System.out.println("�����쳣");
		}
		System.out.println("�������");

	}

}
