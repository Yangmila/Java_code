
public class CatchTest3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("����ʼ");
		int[] arrs=new int[6];
		try
		{
			System.out.println(5/0);
			for(int i=0;i<=8;i++)
            {
				System.out.println(arrs[i]);
		    }
		}
		catch(ArithmeticException ex)
		{
			System.out.println("�����쳣");
		}
		catch(ArrayIndexOutOfBoundsException ex)
		{
			System.out.println("�����±�Խ��");
		}
		catch(Exception ex)
		{
			System.out.println("�����쳣");
		}
		System.out.println("�������");
	}

}
