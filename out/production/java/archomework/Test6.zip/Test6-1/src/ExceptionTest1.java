
public class ExceptionTest1 {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("����ʼ");
		int[] arrs=new int[6];
		for(int i=0;i<=8;i++)
		{
			System.out.println(arrs[i]);
		}
		System.out.println("�������");
	}

}
