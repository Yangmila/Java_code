
public class CatchTest1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("����ʼ");
		int[] arrs=new int[6];
		try
		{
		   for(int i=0;i<=8;i++)
           {
				System.out.println(arrs[i]);
			}
		}
		catch(ArrayIndexOutOfBoundsException ex)
		{
			System.out.println("�����±�Խ��");
		}
		System.out.println("�������");
	}

}
