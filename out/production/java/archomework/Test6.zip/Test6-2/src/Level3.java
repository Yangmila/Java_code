
public class Level3 {

	
	public static void main(String[] args) {
		try
		{
			Level2.test2();
		}
		catch(ArrayIndexOutOfBoundsException ex)
		{
			System.out.println("�����±�Խ��");
		}
	}

}
