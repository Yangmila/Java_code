
public class Level2 {
	public static void test2() throws ArrayIndexOutOfBoundsException
	{
		Level1.test1();
	}
}
