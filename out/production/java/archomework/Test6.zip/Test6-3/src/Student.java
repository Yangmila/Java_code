public class Student {

	private String num;
	private String name;
	private int age;
	
	public void setNum(String num) throws StudentException 
	{
		if(num.length()!=12)
		{
			throw new StudentException("ѧ�ų��Ȳ���12λ");
		}
		else
		{
			if(!numIsAllDigit(num))
			{
				throw new StudentException("ѧ�����з������ַ�");
			}
			else
			{
				this.num = num;
			}
		}
		
	}
	
	//�ж�ѧ�ŵ��ַ��Ƿ�Ϸ��ķ���
	private boolean numIsAllDigit(String num)
	{
		boolean result=true;
		for(int i=0;i<num.length();i++)
		{
			char ch=num.charAt(i);
			if((ch<'0')||(ch>'9'))
			{
				result=false;
				break;
			}
		}
		return result;
	}
	
	
	public String getNum() {
		return num;}
	public void setName(String name) {
		this.name = name;}
	public String getName() {
		return name;}
	public void setAge(int age)throws StudentException {
		if(age<16)
		{
			throw new StudentException("���䲻��С��16��");
		}
		else
		{
			this.age = age;
		}
	}
	public int getAge() {
		return age;}	
	public Student(String num,String name,int age)throws StudentException
	{
		setNum(num);
		setName(name);
		setAge(age);
	}	
}

