import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class AddAndUpdate extends JFrame implements ActionListener
{
	JLabel numLa,nameLa,sexLa;
	JTextField numTxt,nameTxt;
	JComboBox sexCom;
	JButton bt;
	MainFrame main;
	public AddAndUpdate(Student stu,MainFrame main)
	{
		this.main=main;
		this.setSize(300,300);
		this.setLayout(null);
		numLa=new JLabel("ѧ��");
		numLa.setSize(70, 30);
		numLa.setLocation(30, 30);
		this.add(numLa);
		nameLa=new JLabel("����");
		nameLa.setSize(70, 30);
		nameLa.setLocation(30, 70);
		this.add(nameLa);
		sexLa=new JLabel("�Ա�");
		sexLa.setSize(70, 30);
		sexLa.setLocation(30, 110);
		this.add(sexLa);
		
		numTxt=new JTextField();
		numTxt.setSize(120, 30);
		numTxt.setLocation(120, 30);
		this.add(numTxt);
		
		nameTxt=new JTextField();
		nameTxt.setSize(120, 30);
		nameTxt.setLocation(120, 70);
		this.add(nameTxt);
		
		sexCom=new JComboBox();
		sexCom.setSize(120, 30);
		sexCom.setLocation(120, 110);
		sexCom.addItem("��");
		sexCom.addItem("Ů");
		this.add(sexCom);
		
		bt=new JButton();
		bt.setSize(80, 30);
		bt.setLocation(80, 160);
		this.add(bt);
		
		
		if(stu==null)
		{
			this.setTitle("����ѧ��");
			bt.setText("����");
		}
		else
		{
			this.setTitle("�޸�ѧ��");
			numTxt.setText(stu.num);
			numTxt.setEditable(false);
			nameTxt.setText(stu.name);
			sexCom.setSelectedItem(stu.sex);
			bt.setText("�޸�");
		}
		bt.addActionListener(this);
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton bt=(JButton)e.getSource();
		StudentDeal deal=new StudentDeal();
		if(bt.getText().equals("����"))
		{
			String num=numTxt.getText().trim();
			String name=nameTxt.getText().trim();
			String sex=sexCom.getSelectedItem().toString();
			Student stu=new Student(num,name,sex);
			deal.addStudent(stu);
		}
		else
		{
			String num=numTxt.getText().trim();
			String name=nameTxt.getText().trim();
			String sex=sexCom.getSelectedItem().toString();
			Student stu=new Student(num,name,sex);
			deal.updateStu(stu);
		}
		Student[] stus=deal.findAllStudents();
		main.initTable(stus);
		this.dispose();//�رյ�ǰ����
	}
}
