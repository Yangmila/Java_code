
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Student stu=new Student("001","����","��");
	
		//AddAndUpdate test=new AddAndUpdate(stu);
		MainFrame main=new MainFrame();
	}

}
