import java.applet.*;
import java.awt.Color;
import java.awt.event.*;

import javax.swing.*;

public class ItemTest extends JFrame implements ItemListener
{
	JComboBox colorCom;//������ʾ��ɫ��������
	
	public ItemTest()
	{
		this.setSize(300,300);
		this.setLayout(null);
		colorCom=new JComboBox();
		colorCom.addItem("��ɫ");
		colorCom.addItem("��ɫ");
		colorCom.addItem("��ɫ");
		colorCom.setSize(70,30);
		colorCom.setLocation(60, 60);
		colorCom.addItemListener(this);
		this.add(colorCom);
		this.setVisible(true);
	}
	
	public void itemStateChanged(ItemEvent e)
	{
		System.out.println("ok");
		JComboBox com=(JComboBox)e.getSource();
		if(com.getSelectedItem().toString().equals("��ɫ"))
		{
			this.getContentPane().setBackground(Color.red);
		}
		else
		{
			if(com.getSelectedItem().toString().equals("��ɫ"))
			{
				this.getContentPane().setBackground(Color.blue);
			}
			else
			{
				this.getContentPane().setBackground(Color.green);
			}
		}
	}
}
