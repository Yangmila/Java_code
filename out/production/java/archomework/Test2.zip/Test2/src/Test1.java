
public class Test1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
			
		boolean[] arrays=new boolean[5];
		for(int i=0;i<arrays.length;i++)
		{
			System.out.println("*"+arrays[i]+"*");
		}
		
		//String str="abcdef";
		//System.out.println(str.length());
		
		Student[] students=new Student[6];
		students[0]=new Student();
		students[0].num="001";
		students[0].name="tom";
		students[0].age=21;
		for(int i=0;i<students.length;i++)
		{
			System.out.println(students[i]);
		}
	}

}
