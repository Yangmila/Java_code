
public class Student {

	public String num;
	public String name;
	public int age;
	
	//��������ķ���
	public void setAge(int age)
	{
		if(checkAge(age))
		{
			this.age=age;
		}
	}
	
	private boolean checkAge(int age)
	{
		if(age>=16)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
