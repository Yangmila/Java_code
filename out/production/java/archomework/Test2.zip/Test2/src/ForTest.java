
public class ForTest {
	
	public static void chengFaKouJue()
	{
		for(int i=1;i<=9;i++)
		{
			for(int j=i;j<=9;j++)
			{
				if(i*j>=10)
				{
					System.out.print(i+"*"+j+"="+(i*j)+"  ");
				}
				else
				{
					System.out.print(i+"*"+j+"="+(i*j)+"   ");
				}
			}
			System.out.println();
		}
	}
}
