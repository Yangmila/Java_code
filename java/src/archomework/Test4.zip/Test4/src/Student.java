
public class Student {
	//����
	private String num;
	private String name;
	private String sex;
	private int age;
	
	//����
	public void study()
	{
		System.out.println(name+"��ѧϰ");
	}
	
	public void goToClass()
	{
		System.out.println(name+"���Ͽ�");
	}
	
	public void exam()
	{
		System.out.println(name+"�ڿ���");
	}
	
	//���췽��
	public Student(String num,String name,String sex,int age)
	{
		setNum(num);
		setName(name);
		setSex(sex);
		setAge(age);
	}

	public void setNum(String num) {
		this.num=num;
	}

	public String getNum() {
		return num;
	}
	
	public void setName(String name) {
		this.name=name;
	}

	public String getName() {
		return name;
	}

	public void setSex(String sex) {
		if((sex.equals("��"))||(sex.equals("Ů")))
		{
			this.sex = sex;
		}
	}

	public String getSex() {
		return sex;
	}

	public void setAge(int age) {
		if(age>=16)
		{
			this.age=age;
		}
	}

	public int getAge() {
		return age;
	}
	
	public boolean equals(Student student)
	{
		boolean result=true;
		if(!num.equals(student.getNum()))
		{
			result=false;
		}
		if(!name.equals(student.getName()))
		{
			result=false;
		}
		if(!sex.equals(student.getSex()))
		{
			result=false;
		}
		if(age!=student.getAge())
		{
			result=false;
		}
		return result;
	}
	
	public String toString()
	{
		String str="";
		str="����:"+name+",ѧ��:"+num+",�Ա�:"+sex+",����:"+age;
		return str;
	}
}
