
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		StudentDeal deal=new StudentDeal();
		/*Student stu=deal.findStuByNum("067");
		System.out.println(stu.name);
		
		Student newstu=new Student("078","����","��");
		deal.addStudent(newstu);*/
		deal.delStuByNum("023");
		//deal.delStuByNum("078");

	}

}
