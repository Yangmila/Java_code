import java.io.*;
public class FileTest {

	public static void main(String[] args) {
		
		File file=new File("d:\\student.txt");
		System.out.println(file.getParent());
		System.out.println(file.canExecute());
		System.out.println(file.canRead());
		file.delete();
	}

}
