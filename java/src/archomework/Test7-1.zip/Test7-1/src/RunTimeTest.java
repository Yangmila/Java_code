import java.io.IOException;


public class RunTimeTest {

	public static void main(String[] args) {
		Runtime run=Runtime.getRuntime();
		try {
			run.exec("calc.exe");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
