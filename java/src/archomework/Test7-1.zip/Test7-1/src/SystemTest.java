
public class SystemTest {

	public static void main(String[] args) {
		String[] strs={"a","b","c","d","e"};
		String[] strs1=new String[3];
		System.arraycopy(strs, 1, strs1, 0, 3);
		for(int i=0;i<strs1.length;i++)
		{
			System.out.println(strs1[i]);
		}
	}

}
