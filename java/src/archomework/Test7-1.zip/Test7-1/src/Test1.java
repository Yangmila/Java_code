
public class Test1 {

	
	public static void main(String[] args) {
		String str="123";
		String str1="456";
		System.out.println(Integer.parseInt(str)+Integer.parseInt(str1));

		
		System.out.println(5+6);
		System.out.println(String.valueOf(5+6));
	}

}
