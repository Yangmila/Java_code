
public class StringBufferTest {

	
	public static void main(String[] args) {
		String str="123";
		str=str+"456";
		
		

	}

}
