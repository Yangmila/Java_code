
public class SplitTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="201806080101,�ŷ�,Ů,19,�������ѧ�뼼��";
		showInfo(str);
	}
	
	public static void showInfo(String str)
	{
		String[] stuInfs=str.split(",");
		System.out.println("ѧ��Ϊ:"+stuInfs[0]);
		System.out.println("����Ϊ:"+stuInfs[1]);
		System.out.println("�Ա�Ϊ:"+stuInfs[2]);
		System.out.println("����Ϊ:"+stuInfs[3]);
		System.out.println("רҵΪ:"+stuInfs[4]);
	}

}
