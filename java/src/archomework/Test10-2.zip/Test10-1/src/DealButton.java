import java.awt.event.*;

import javax.swing.JButton;
public class DealButton implements ActionListener
{
	private LoginForm4 loginForm;
	
	public DealButton(LoginForm4 loginForm)
	{
		this.loginForm=loginForm;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton bt=(JButton)e.getSource();
		//��ȡ�¼�ԴǿתΪ��ť����
		if(bt.getText().equals("��¼"))
		{
			String user=loginForm.userText.getText().trim();
			String pwd=loginForm.pwdText.getText().trim();
			if((user.equals("admin"))&&(pwd.equals("123")))
			{
				Cal cal=new Cal();
				loginForm.setVisible(false);
			}
		}
		else
		{
			System.exit(0);
			//���������˳�
		}
	
		
	}

}
