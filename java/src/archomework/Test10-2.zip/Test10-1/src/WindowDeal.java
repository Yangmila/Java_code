import java.awt.event.*;

public class WindowDeal extends WindowAdapter
{
	private LoginForm2 loginForm;
	
	public WindowDeal(LoginForm2 loginForm)
	{
		this.loginForm=loginForm;
	}
	
	public void windowDeactivated(WindowEvent e) {
		System.out.println("����ʧȥ����");
	}
	
	public void windowActivated(WindowEvent e) {
		System.out.println("�����ý���");
	}
}
