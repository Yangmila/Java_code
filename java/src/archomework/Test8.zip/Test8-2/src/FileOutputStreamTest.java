import java.io.*;
public class FileOutputStreamTest {


	public static void main(String[] args) {
		try {
			FileOutputStream fos=new FileOutputStream("d:\\20201109.txt");
			fos.write(201);
			fos.write(194);
			fos.write(206);
			fos.write(247);
			fos.close();//�ر���
		} 
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("�ļ�δ�ҵ�");
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("�ļ���ȡ����");
		}

	}

}
